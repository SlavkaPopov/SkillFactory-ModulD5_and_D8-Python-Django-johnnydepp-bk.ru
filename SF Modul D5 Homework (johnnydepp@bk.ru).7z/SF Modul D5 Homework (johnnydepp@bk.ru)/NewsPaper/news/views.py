from django.urls import reverse_lazy
from django.views.generic import (
    ListView, DetailView, CreateView, UpdateView, DeleteView
)
from django.shortcuts import redirect

from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .filters import PostFilter
from .forms import PostForm
from .models import Post


class PostList(ListView):
    model = Post
    ordering = '-time_in'
    template_name = 'news.html'
    context_object_name = 'posts'
    paginate_by = 10


class PostSearch(ListView):
    model = Post
    ordering = '-time_in'
    template_name = 'search.html'
    context_object_name = 'search'
    paginate_by = 5

    def get_queryset(self):
        queryset = super().get_queryset()
        self.filterset = PostFilter(self.request.GET, queryset)
        return self.filterset.qs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Добавляем в контекст объект фильтрации.
        context['filterset'] = self.filterset
        return context


class PostDetail(DetailView):
    model = Post
    template_name = 'new.html'
    context_object_name = 'new'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # context['time_now'] = datetime.utcnow()
        # context['New post is coming soon'] = None
        context['is_not_authors'] = not self.request.user.groups.filter(name='author').exists()
        context['user_auth'] = self.request.user.is_authenticated
        id = self.kwargs.get('pk')
        post = Post.objects.get(pk=id)
        is_subscribersusers = True
        for cat in post.name_category.all():
            if self.request.user not in cat.sub_user.all():
                is_subscribersusers = False
        context['is_subscribersusers'] = is_subscribersusers
        return context


class PostCreate(LoginRequiredMixin, CreateView, PermissionRequiredMixin):
    # Указываем нашу разработанную форму
    form_class = PostForm
    # модель постов
    model = Post
    # и новый шаблон, в котором используется форма.
    template_name = 'news_create.html'
    permission_required = ('post.add_post')

    def form_valid(self, form):
        post_in = form.save(commit=False)
        if self.request.method == 'POST':
            path_info = self.request.META['PATH_INFO']
            if path_info == '/news/news/create/':
                post_in.type_of_post = 'NW'
            elif path_info == '/news/article/create/':
                post_in.type_of_post = 'PS'
        post_in.save()
        return super().form_valid(form)


# Добавляем представление для изменения товара.
class PostUpdate(LoginRequiredMixin, UpdateView, PermissionRequiredMixin):
    form_class = PostForm
    model = Post
    template_name = 'post_edit.html'
    permission_required = ('post.change_post')


# Представление удаляющее товар.
class PostDelete(LoginRequiredMixin, DeleteView, PermissionRequiredMixin):
    model = Post
    template_name = 'post_delete.html'
    success_url = reverse_lazy('posts')
    permission_required = ('post.delete_post')


@login_required
def subscribe(request, pk):
    user = User.objects.get(pk=request.user.id)
    post = Post.objects.get(pk=pk)
    category = post.name_category.all()
    for cat in category:
        if user not in cat.sub_user.all():
            cat.sub_user.add(user)
    return redirect('/news/')


@login_required
def unsubscribe(request, pk):
    user = User.objects.get(pk=request.user.id)
    post = Post.objects.get(pk=pk)
    category = post.name_category.all()
    for cat in category:
        if user in cat.sub_user.all():
            cat.sub_user.remove(user)
    return redirect('/news/')
