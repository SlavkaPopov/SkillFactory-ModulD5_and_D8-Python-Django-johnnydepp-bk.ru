sport = 'SP'
policy = 'PL'
formation = 'FM'
culture = 'CL'
rest = 'RS'
other = 'OT'

CATEGORY_THEMES = [
    (sport, 'спорт'),
    (policy, 'политика'),
    (formation, 'образование'),
    (culture, 'культура'),
    (rest, 'отдых'),
    (other, 'другое'),
]


news = 'NW'
post = 'PS'

TYPE_POST = [
    (news, 'новость'),
    (post, 'статья')
]

